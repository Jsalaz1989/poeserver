# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['polls', 'polls.migrations']

package_data = \
{'': ['*'],
 'polls': ['static/polls/*', 'static/polls/images/*', 'templates/polls/*']}

setup_kwargs = {
    'name': 'django-polls',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'jsalaz1989',
    'author_email': 'jsalaz1989@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
