# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['upload', 'upload.migrations']

package_data = \
{'': ['*'], 'upload': ['templates/*']}

setup_kwargs = {
    'name': 'django-upload',
    'version': '0.2.0',
    'description': '',
    'long_description': None,
    'author': 'jsalaz1989',
    'author_email': 'jsalaz1989@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
